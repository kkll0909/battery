<?php

namespace app\index\controller;

use app\common\controller\Frontend;

class Index extends Frontend
{

    

}
