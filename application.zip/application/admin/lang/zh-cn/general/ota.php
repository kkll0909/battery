<?php

return [
    'Otaname'   => 'OTA名称',
    'Otatype'   => 'OTA标识',
    'Otastatus' => 'OTA状态'
];
