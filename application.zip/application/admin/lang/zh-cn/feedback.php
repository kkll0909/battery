<?php

return [
    'Pid'    => '上级',
    'Userid' => '用户ID',
    'Desc'   => '内容',
    'Tel'    => '联系方式'
];
