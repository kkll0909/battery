<?php

return [
    'Images'     => '封面',
    'Vurl'     => '视频',
    'Ntype'     => '分类',
    //
    'word'      => '文章',
    'video'      => '视频',
    'Title'     => '标题',
    'Abstract'  => '摘要',
    'Desc'      => '内容',
    'Ctime'     => '创建时间',
    'Status'    => '状态',
    'Recommend' => '推荐'
];
