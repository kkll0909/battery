<?php

return [
    'Msgid'      => '信息ID',
    'Userid'     => '用户ID',
    'Createtime' => '阅读时间'
];
