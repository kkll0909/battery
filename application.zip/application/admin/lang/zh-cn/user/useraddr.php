<?php

return [
    'Userid'  => '用户ID',
    'Address' => '地址',
    'Tel'     => '电活',
    'Name'    => '姓名',
    'Status'  => 'show,close',
    'Ctime'   => '创建时间'
];
