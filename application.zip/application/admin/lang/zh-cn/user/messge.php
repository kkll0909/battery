<?php

return [
    'Title'  => '标题',
    'Desc'   => '内容',
    'Type'   => 'msg,sys,order,pay',
    'Ctime'  => '创建时间',
    'Userid' => '被通知的用户,0为全部',
    'Status' => 'show,close'
];
