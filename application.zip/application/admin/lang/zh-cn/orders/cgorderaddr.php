<?php

return [
    'Oid'     => '订单ID',
    'Address' => '地址',
    'Tel'     => '电话',
    'Name'    => '姓名',
    'Type'    => '取货方式',
    'Express'    => '快递',
    'Self'    => '自提',
];
