<?php

return [
    'Fromid'  => '来源方ID',
    'Toid'    => '目标方ID',
    'Cgoid'   => '采购ID',
    'Orderno' => '订单号',
    'Stime'   => '创建时间',
    'Etime'   => '完成时间',
    'Money'   => '金额',
    'Status'  => '订单状态'
];
