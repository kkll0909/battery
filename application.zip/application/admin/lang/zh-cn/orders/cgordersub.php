<?php

return [
    'Oid'   => '订单ID',
    'Batid' => '电池ID',
    'Batno' => '电池序号',
    'Sum'   => '数量',
    'Price' => '价格'
];
