<?php

return [
    'Oid'       => '订单ID',
    'Isy'       => '类型',
    'Deposit'   =>'押金',
    'Stages'   =>'分期',
    'Paymoney'  => '应付金额',
    'Paysum'    => '期数',
    'Paydate'   => '应付日期',
    'Paystatus' => '支付状态',
];
