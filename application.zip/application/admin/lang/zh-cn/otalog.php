<?php

return [
    'Type'    => '日志类型',
    'Sbno'    => '设备序列号',
    'Stime'   => '更新日期',
    'Lognote' => '日志内容'
];
