<?php

return [
    'Batid'      => '电池ID',
    'Belongid'   => '归属ID',
    'Belongtype' => '所属类型',
    'User'=>'用户',
    'Manage'=>'商家',
    'Isuse'=>'使用方式',
    'Self'=>'录入',
    'Sale'=>'销售',
    'Lease'=>'租赁',
    'Allocation'=>'分配',
    'Status'     => '状态',
    'Stime'      => '开始时间',
    'Etime'      => '结束时间'
];
