<?php

return [
    'Admin_id' => '厂家帐户ID',
    'Faname'   => '厂家名称',
    'Fatel'    => '厂家电话',
    'Faaddr'   => '厂家地圵',
    'Otaparam' => 'OTA参数',
    'Status'   => 'show,close'
];
