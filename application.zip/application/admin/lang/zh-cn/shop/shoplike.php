<?php

return [
    'Shopid' => '门店ID',
    'Userid' => '用户ID',
    'Type'   => '类型',
    'collect'=> '收藏',
    'like'=> '评价',
    'Score'  => '得分',
    'Ctime'  => '操作时间',
];
