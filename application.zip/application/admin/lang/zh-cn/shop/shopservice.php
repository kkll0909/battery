<?php

return [
    'Shopid' => '门店ID',
    'Title'  => '标题',
    'Note'   => '内容',
    'Status' => '状态',
    'Ctime'  => '创建时间'
];
