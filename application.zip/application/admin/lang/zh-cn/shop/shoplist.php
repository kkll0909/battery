<?php

return [
    'Shopid' => '门店ID',
    'Sbimg' => '产品图',
    'Sbname' => '产品名称',
    'Sbtype' => '方式',
    //
    'Buy' => '出售',
    'Zp' => '租赁',
    'Sbgg' => '规格',
    'Sbtext' => '详情',
    'Money'  => '价格',
    'Status' => '状态',
    'Zpmoney'  => '租赁价格',
    'Buymoney'  => '出售价格',
    'Deposit' => '押金',
    'Usetype' => '付租方式',
    'Payuse' => '先付后用',
    'Usepay' => '先用后付',
    'paytype' => '付款方式',
    'M' => '月付',
    'J' => '季付',
    'N' => '年付',
];
