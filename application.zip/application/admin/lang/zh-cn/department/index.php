<?php
return [
    'Department'                                            => '部门',
    'Principal'                                             => '负责部门',
    'Children'                                              => '子类',
    'Batch entry is supported, one record per line'         => '支持批量录入，一行一条记录',
    'Toggle sub menu'                                       => '切换菜单',
    "Top-level organization cannot be modified to lower level organization"=>"顶级组织不能修改成下级",

];
