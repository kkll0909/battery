<?php

return [
    'Admin_id' => 'admin id',
    'Money'    => '金额',
    'Bankname' => '机构',
    'Bankno'   => '帐号',
    'Bankckr'  => '持有人',
    'Status'   => 'nopay,pay,fail',
    'Note'     => '备注'
];
