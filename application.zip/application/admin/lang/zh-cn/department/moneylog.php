<?php

return [
    'Admin_id'   => '会员ID',
    'Payway'     => '方式 wx ali bank',
    'Form'       => '来源 order comm withdraw',
    'Money'      => '变更余额',
    'Before'     => '变更前余额',
    'After'      => '变更后余额',
    'Memo'       => '备注',
    'Createtime' => '创建时间'
];
