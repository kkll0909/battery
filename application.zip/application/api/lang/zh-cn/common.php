<?php

return [
    'Shop does not exist'=>"门店不存在",
    'Product does not exist'=>"产品不存在",
    'Order does not exist'=>"订单不存在",
    'Sb does not exist'=>"设备不存在",
];
