<?php

return [
    'Batid'      => '电池ID',
    'Belongid'   => '归属ID',
    'Belongtype' => 'user,manage',
    'Status'     => 'show,close',
    'Stime'      => '开始时间',
    'Etime'      => '结束时间'
];
