<?php

return [
    'Admin_id'      => '门店帐号',
    'Spname'        => '门店名称',
    'Spimgs'        => '门店图片',
    'Spnote'        => '门店介绍',
    'Isopen'        => '是否营业',
    'Tag'           => '标签',
    'Status'        => '状态',
    'Splng' => '经度',
    'Splat' => '纬度',
    'Spaddr' => '定位地址',
    'Spaddrbc' => '具体地址',
    'Opening' => '营业中',
    'Closing' => '休息中'
];
