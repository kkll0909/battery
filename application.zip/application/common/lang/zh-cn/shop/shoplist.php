<?php

return [
    'Shopid' => '门店ID',
    'Sbname' => '产品名称',
    'Sbtype' => '方式',
    //
    'Buy' => '出售',
    'Zp' => '租赁',
    'Sbgg' => '规格',
    'Sbtext' => '详情',
    'Money'  => '价格',
    'Status' => '状态',
    'Zpmoney'  => '租赁价格',
    'Buymoney'  => '出售价格',
];
